# 3DHTM Studio — Website

Static website source for Vercel. No npm dependencies or build step are required.

## Deploy
Import this repository into Vercel and use the repository root as the project root. Framework preset: Other. Build command: leave empty. Output directory: leave empty (or `.` if the UI requires a value).

## Before launch
- Replace the sample WhatsApp number `628123456789` in `index.html` with the business WhatsApp number.
- Replace social links with the correct Instagram, Facebook, and TikTok URLs; currently they use `#` placeholders.

The image assets have been optimized to WebP and the intro video has been compressed. The pages remain `index.html` and `Jasa-desain.html`.
