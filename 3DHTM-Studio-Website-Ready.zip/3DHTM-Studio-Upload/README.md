# 3DHTM Studio

Website resmi 3DHTM Studio — layanan desain 3D dan 3D printing.

## Struktur
- `index.html` — halaman utama
- `Jasa-desain.html` — halaman jasa desain
- `CSS/` — stylesheet
- `JSC/` — JavaScript
- `img/` — gambar website (WebP untuk ukuran lebih ringan)
- `Video/intro.webm` — video intro

Website ini berupa situs statis HTML, CSS, dan JavaScript; tidak memerlukan proses build npm.
